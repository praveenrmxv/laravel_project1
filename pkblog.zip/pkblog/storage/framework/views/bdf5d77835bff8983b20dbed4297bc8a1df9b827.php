<?php echo e($slot); ?>

<?php /**PATH D:\new_laravel\pkblog\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>